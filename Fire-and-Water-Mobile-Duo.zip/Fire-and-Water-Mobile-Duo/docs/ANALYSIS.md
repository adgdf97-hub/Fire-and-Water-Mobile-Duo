# SWF technical analysis

File analysed: `Fireboy_Watergirl_2_extracted.swf` (never modified).

| Property | Value |
|---|---|
| SHA-256 | `ad26dbf85aeef80da4b87afbce56d28146cb559b497d11d6ce725cb1fcd51708` |
| Size | 4,813,264 bytes |
| Container | `FWS` (uncompressed), SWF version 10 |
| Stage | 640 x 480 px, 25 fps, 3 main-timeline frames |
| Language | **ActionScript 3** (FileAttributes flag 0x08 set) |
| Code | 1 `DoABC` block, 288,158 bytes, ABC version 46.16 |
| Constant pool | 1,803 strings |
| SymbolClass | 154 symbol -> class bindings (2 SymbolClass tags) |
| Main class | `Game` (symbol id 0) |

## Embedded resources (tag counts)
DefineSprite 275, DefineShape/2/3/4 476 total, DefineText 192, DefineEditText 39, DefineButton2 33,
DefineMorphShape 16, DefineFont3 8, **DefineSound 29** (~1.4 MB), bitmaps: DefineBitsLossless/2 20, DefineBitsJPEG3 17,
DefineBits 3. No DefineBinaryData, no video.

## Findings relevant to Android / Ruffle
* Pure AS3 + vector/bitmap/sound assets -> a normal Ruffle (AVM2) candidate. No Socket, LocalConnection,
  ExternalInterface, ByteArray, Multitouch or Accelerometer usage found in the constant pool.
* Input uses `KeyboardEvent` (KEY_DOWN / KEY_UP, `keyCode`). Touch controls therefore work by synthesising keyboard events.
* Uses `SharedObject` (progress saving) -> Ruffle supports it (stored in WebView localStorage).
* **Risk:** the SWF references third-party ad / platform services that no longer exist
  (`CPMStar:AdLoader`, `server.cpmstar.com/adviewas3.swf`, `agi.armorgames.com/assets/agi/AGI.swf`) and `navigateToURL`
  links to armorgames.com. If the preloader waits for those, the game may stall at the loading screen.
  This could NOT be verified here (no browser/device in the build sandbox). It must be tested on a device.
* A `Protect` tag is present (debugger password hash). It does not affect playback.
* Stage is 4:3; on a 20:9 phone the game is letterboxed (`scale: showAll`). Touch pads are drawn over the black bars.
* Default controls (verify in-game): Fireboy = arrow keys, Watergirl = W/A/D. The mapping is one table in `index.html` (`KEYS`).

## Runtime decision
| Option | Verdict |
|---|---|
| Ruffle web build inside Android WebView (chosen) | No native code, so no ABI problem: works on armeabi-v7a/Android 14 as long as the system WebView supports WebAssembly (Chrome 91+). License MIT OR Apache-2.0 (verified in the npm package: `LICENSE_MIT`, `LICENSE_APACHE`). |
| Official Ruffle Android app / native build | Needs a Rust + NDK toolchain, not reachable from the sandbox; would add 32-bit ARM native build risk. Not attempted. |
| Adobe AIR / Flash runtime | Discontinued, proprietary, not redistributable. Rejected. |
| Rewrite the game | Not needed unless Ruffle fails on a device. |
