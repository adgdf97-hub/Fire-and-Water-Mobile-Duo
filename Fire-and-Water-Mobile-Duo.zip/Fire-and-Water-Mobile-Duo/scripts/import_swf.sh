#!/usr/bin/env bash
# Copies YOUR OWN copy of the original SWF into the app assets (bundled mode).
# The file is git-ignored on purpose; do not publish it in a public repository.
# Usage: scripts/import_swf.sh /path/to/game.swf
set -euo pipefail
SRC="${1:?usage: $0 /path/to/game.swf}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
[ "$(head -c3 "$SRC")" = "FWS" ] || [ "$(head -c3 "$SRC")" = "CWS" ] || [ "$(head -c3 "$SRC")" = "ZWS" ] \
  || { echo "Not an SWF file"; exit 1; }
mkdir -p "$ROOT/app/src/main/assets/game"
cp "$SRC" "$ROOT/app/src/main/assets/game/game.swf"   # copy only; the original is never modified
echo "SHA-256: $(sha256sum "$SRC" | cut -d' ' -f1)"
echo "Imported to app/src/main/assets/game/game.swf"
