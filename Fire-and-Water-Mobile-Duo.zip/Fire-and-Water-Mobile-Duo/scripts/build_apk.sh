#!/usr/bin/env bash
# Builds a debug APK (signed with the Android debug key, installable directly).
# Requirements: JDK 17, Android SDK (ANDROID_HOME), Node/npm, and either ./gradlew or Gradle 8.7+.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
bash scripts/fetch_ruffle.sh
if [ -x ./gradlew ]; then G=./gradlew; else G=gradle; fi
$G --no-daemon :app:assembleDebug
mkdir -p dist
cp app/build/outputs/apk/debug/app-debug.apk dist/Fire-and-Water-Mobile-Duo-debug.apk
echo "APK: dist/Fire-and-Water-Mobile-Duo-debug.apk"
