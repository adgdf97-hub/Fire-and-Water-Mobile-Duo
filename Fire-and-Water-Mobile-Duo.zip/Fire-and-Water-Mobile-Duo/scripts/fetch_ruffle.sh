#!/usr/bin/env bash
# Downloads the official self-hosted Ruffle web build from npm (MIT OR Apache-2.0)
# and copies it into the app's web assets. Source maps are dropped to save space.
set -euo pipefail
VERSION="${RUFFLE_VERSION:-0.7.1}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="$ROOT/app/src/main/assets/web/ruffle"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
command -v npm >/dev/null || { echo "npm is required"; exit 1; }
( cd "$TMP" && npm pack "@ruffle-rs/ruffle@$VERSION" --silent && tar xzf ruffle-rs-ruffle-*.tgz )
rm -rf "$DEST"; mkdir -p "$DEST"
cp "$TMP"/package/*.js "$TMP"/package/*.wasm "$TMP"/package/LICENSE_* "$DEST"/
echo "Ruffle $VERSION installed into $DEST ($(du -sh "$DEST" | cut -f1))"
