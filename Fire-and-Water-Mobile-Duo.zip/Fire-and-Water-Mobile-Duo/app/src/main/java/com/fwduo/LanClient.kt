package com.fwduo

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import java.io.BufferedWriter
import java.net.InetSocketAddress
import java.net.Socket

/** Runs on the guest phone (Watergirl controller). */
class LanClient(
    context: Context,
    private val onEvent: (String, String) -> Unit
) {
    private val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var socket: Socket? = null
    private var writer: BufferedWriter? = null
    private var discovery: NsdManager.DiscoveryListener? = null
    @Volatile private var resolving = false

    /** Find the host via mDNS, then connect. */
    fun discoverAndJoin(pin: String) {
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) = onEvent("searching", "")
            override fun onServiceFound(i: NsdServiceInfo) {
                if (!i.serviceType.startsWith("_fwduo._tcp") || resolving) return
                resolving = true
                @Suppress("DEPRECATION")
                nsd.resolveService(i, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(s: NsdServiceInfo, e: Int) { resolving = false }
                    override fun onServiceResolved(s: NsdServiceInfo) {
                        @Suppress("DEPRECATION")
                        val host = s.host?.hostAddress
                        stopDiscovery()
                        if (host != null) joinByIp(host, s.port, pin) else onEvent("error", "resolve")
                    }
                })
            }
            override fun onServiceLost(i: NsdServiceInfo) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) = onEvent("error", "nsd-discovery:$e")
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
        }
        discovery = l
        nsd.discoverServices(LanProtocol.SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, l)
    }

    private fun stopDiscovery() {
        try { discovery?.let { nsd.stopServiceDiscovery(it) } } catch (_: Exception) {}
        discovery = null
        resolving = false
    }

    /** Manual fallback if mDNS is blocked by the router (common on guest/AP-isolated Wi-Fi). */
    fun joinByIp(host: String, port: Int, pin: String) {
        Thread({
            try {
                val s = Socket()
                s.tcpNoDelay = true
                s.connect(InetSocketAddress(host, port), 5000)
                val w = s.getOutputStream().bufferedWriter()
                val r = s.getInputStream().bufferedReader()
                w.write("HELLO $pin\n"); w.flush()
                if (r.readLine()?.trim() != "OK") { s.close(); onEvent("denied", ""); return@Thread }
                socket = s; writer = w
                onEvent("connected", host)
                while (r.readLine() != null) { /* host sends nothing else yet */ }
            } catch (e: Exception) {
                onEvent("error", e.message ?: "connect")
            } finally {
                onEvent("disconnected", "")
                close()
            }
        }, "fwduo-client").start()
    }

    fun sendKey(down: Boolean, key: String) {
        val w = writer ?: return
        Thread {
            try { synchronized(w) { w.write("K ${if (down) "D" else "U"} $key\n"); w.flush() } }
            catch (_: Exception) {}
        }.start()
    }

    fun close() {
        stopDiscovery()
        try { socket?.close() } catch (_: Exception) {}
        socket = null; writer = null
    }
}
