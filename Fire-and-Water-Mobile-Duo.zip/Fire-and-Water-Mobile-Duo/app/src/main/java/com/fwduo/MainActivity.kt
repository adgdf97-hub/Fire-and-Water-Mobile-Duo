package com.fwduo

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var gameDir: File
    private var host: LanHost? = null
    private var client: LanClient? = null
    private var hostPort = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        gameDir = File(filesDir, "game").apply { mkdirs() }

        val loader = WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/imported/", WebViewAssetLoader.InternalStoragePathHandler(this, gameDir))
            .build()

        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_NO_CACHE
        }
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.setBackgroundColor(0xFF000000.toInt())
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val resp = loader.shouldInterceptRequest(r.url) ?: return null
                val path = r.url.path ?: return resp
                // Make sure .wasm / .swf get proper MIME types (needed for streaming compile).
                val mime = when {
                    path.endsWith(".wasm") -> "application/wasm"
                    path.endsWith(".swf") -> "application/x-shockwave-flash"
                    path.endsWith(".js") -> "text/javascript"
                    else -> null
                }
                return if (mime != null) WebResourceResponse(mime, null, resp.data) else resp
            }
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/web/index.html")
    }

    private fun js(event: String, payload: String) {
        val o = JSONObject().put("e", event).put("p", payload).toString()
        runOnUiThread { web.evaluateJavascript("window.FWDuo&&FWDuo.onNative($o)", null) }
    }

    private fun localIp(): String = try {
        NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
            .firstOrNull { !it.isLoopbackAddress && it is Inet4Address }?.hostAddress ?: ""
    } catch (_: Exception) { "" }

    inner class Bridge {
        @JavascriptInterface fun hasBundledGame(): Boolean =
            try { assets.list("game")?.any { it.endsWith(".swf") } == true } catch (_: Exception) { false }

        @JavascriptInterface fun bundledGameName(): String =
            try { assets.list("game")?.firstOrNull { it.endsWith(".swf") } ?: "" } catch (_: Exception) { "" }

        @JavascriptInterface fun hasImportedGame(): Boolean = File(gameDir, "game.swf").exists()

        @JavascriptInterface fun pickSwf() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                }
                @Suppress("DEPRECATION")
                startActivityForResult(i, 42)
            }
        }

        @JavascriptInterface fun startHost() {
            stopNet()
            try {
                val h = LanHost(this@MainActivity, { e, p -> js(e, p) }) { down, key ->
                    runOnUiThread { web.evaluateJavascript("FWDuo.remoteKey($down,'$key')", null) }
                }
                hostPort = h.start(); host = h
                js("hostInfo", JSONObject().put("ip", localIp()).put("port", hostPort).put("pin", h.pin).toString())
            } catch (e: Exception) { js("error", e.message ?: "host") }
        }

        @JavascriptInterface fun joinAuto(pin: String) {
            stopNet(); client = LanClient(this@MainActivity) { e, p -> js(e, p) }.also { it.discoverAndJoin(pin) }
        }

        @JavascriptInterface fun joinManual(ip: String, port: Int, pin: String) {
            stopNet(); client = LanClient(this@MainActivity) { e, p -> js(e, p) }.also { it.joinByIp(ip, port, pin) }
        }

        @JavascriptInterface fun sendKey(down: Boolean, key: String) { client?.sendKey(down, key) }
        @JavascriptInterface fun stopNetwork() = stopNet()
    }

    private fun stopNet() {
        host?.stop(); host = null
        client?.close(); client = null
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == Activity.RESULT_OK) {
            val uri: Uri = data?.data ?: return
            Thread {
                try {
                    contentResolver.openInputStream(uri)!!.use { input ->
                        File(gameDir, "game.swf").outputStream().use { input.copyTo(it) }
                    }
                    js("swfImported", "ok")
                } catch (e: Exception) { js("error", "import:" + (e.message ?: "")) }
            }.start()
        }
    }

    override fun onDestroy() { stopNet(); super.onDestroy() }
}
