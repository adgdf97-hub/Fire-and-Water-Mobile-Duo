package com.fwduo

/**
 * Line-based TCP protocol (UTF-8, '\n' terminated):
 *   client -> host:  HELLO <pin>
 *   host   -> client: OK | DENIED
 *   client -> host:  K <D|U> <KeyName>      e.g. "K D ArrowUp"
 * The host only accepts the keys that belong to the guest's character.
 */
object LanProtocol {
    const val SERVICE_TYPE = "_fwduo._tcp."
    const val SERVICE_NAME = "FireWaterDuo"
    val GUEST_KEYS = setOf("KeyW", "KeyA", "KeyD") // Watergirl
}
