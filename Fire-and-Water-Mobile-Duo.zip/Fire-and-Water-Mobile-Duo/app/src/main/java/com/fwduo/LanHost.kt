package com.fwduo

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import java.net.ServerSocket
import java.net.Socket
import kotlin.random.Random

/** Runs on the phone that shows the game (Fireboy phone). Accepts ONE guest (Watergirl). */
class LanHost(
    context: Context,
    private val onEvent: (String, String) -> Unit,   // (event, payload) -> UI
    private val onGuestKey: (down: Boolean, key: String) -> Unit
) {
    private val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var server: ServerSocket? = null
    private var guest: Socket? = null
    private var regListener: NsdManager.RegistrationListener? = null
    @Volatile private var running = false
    val pin: String = Random.nextInt(1000, 10000).toString()

    fun start(): Int {
        val ss = ServerSocket(0)
        server = ss
        running = true
        register(ss.localPort)
        Thread({ acceptLoop(ss) }, "fwduo-accept").start()
        return ss.localPort
    }

    private fun register(port: Int) {
        val info = NsdServiceInfo().apply {
            serviceName = LanProtocol.SERVICE_NAME
            serviceType = LanProtocol.SERVICE_TYPE
            setPort(port)
        }
        val l = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(i: NsdServiceInfo) = onEvent("hostReady", i.serviceName)
            override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) = onEvent("error", "nsd-register:$e")
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
        }
        regListener = l
        nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, l)
    }

    private fun acceptLoop(ss: ServerSocket) {
        while (running) {
            try {
                val s = ss.accept()
                s.tcpNoDelay = true
                Thread({ handle(s) }, "fwduo-guest").start()
            } catch (_: Exception) { break }
        }
    }

    private fun handle(s: Socket) {
        try {
            val r = s.getInputStream().bufferedReader()
            val w = s.getOutputStream().bufferedWriter()
            val hello = r.readLine()?.trim() ?: return
            if (hello != "HELLO $pin" || guest != null) {
                w.write("DENIED\n"); w.flush(); s.close(); return
            }
            guest = s
            w.write("OK\n"); w.flush()
            onEvent("guestJoined", s.inetAddress.hostAddress ?: "")
            while (running) {
                val line = r.readLine() ?: break
                val p = line.trim().split(' ')
                if (p.size == 3 && p[0] == "K" && (p[1] == "D" || p[1] == "U") && p[2] in LanProtocol.GUEST_KEYS) {
                    onGuestKey(p[1] == "D", p[2])
                }
            }
        } catch (_: Exception) {
        } finally {
            if (guest === s) { guest = null; onEvent("guestLeft", "") }
            try { s.close() } catch (_: Exception) {}
        }
    }

    fun stop() {
        running = false
        try { regListener?.let { nsd.unregisterService(it) } } catch (_: Exception) {}
        try { guest?.close() } catch (_: Exception) {}
        try { server?.close() } catch (_: Exception) {}
    }
}
