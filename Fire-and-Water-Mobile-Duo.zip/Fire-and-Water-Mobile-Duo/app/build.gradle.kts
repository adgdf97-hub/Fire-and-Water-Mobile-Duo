plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.fwduo"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.fwduo.mobileduo"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
        // The app contains no native code (Ruffle runs as WebAssembly inside the
        // system WebView), so the APK is architecture-neutral and runs on armeabi-v7a.
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    androidResources {
        // .wasm is already compressed; keep .swf/.wasm stored for fast loading
        noCompress += listOf("wasm", "swf")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
}
